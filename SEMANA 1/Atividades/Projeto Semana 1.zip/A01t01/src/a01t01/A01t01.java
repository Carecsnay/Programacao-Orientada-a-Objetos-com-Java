package a01t01;

public class A01t01 {
    public static void main(String[] args) {
        System.out.println("Olá, me chamo Bruno Benicio.");
    }
}