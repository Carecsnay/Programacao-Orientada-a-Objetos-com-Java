package a08ex03;

public class Mesa extends Movel {
    @Override
    public void meuNome () {
        System.out.println("eu sou uma mesa!");
    }
    
}
