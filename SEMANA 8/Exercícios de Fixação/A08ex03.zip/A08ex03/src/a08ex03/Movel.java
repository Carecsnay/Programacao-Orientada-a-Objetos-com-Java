package a08ex03;
/*
As classes abstratas são as que não permitem realizar qualquer 
tipo de instância. São classes feitas especialmente para serem modelos para suas classes derivadas. */
public abstract class Movel {
    
    public void meuNome() {
        System.out.println("eu sou um móvel");
    }
}
