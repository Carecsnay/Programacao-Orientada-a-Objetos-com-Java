package a07t01;

/*

    Aluno: Bruno Benicio de Andrade Lima
    Cidade: Castelo do Piauí - PI

 */

public class A07t01 {

/*
    Crie as classes Fabricante (nome), 
    Produto(nome, modelo e Fabricante) 
    e instancie os objetos logitech, dell e samsung. 
    Instancie também os objetos hd, mouse e teclado. 
    Mostre, a partir do objeto hd, o seu nome, modelo e a nome do seu fabricante. 
    Os construtores vazio e completo devem ser adicionados nas classes.
*/
    
    public static void main(String[] args) {
        //INSTANCIANDO FABRICANTES
        Fabricante logitech = new Fabricante("Logitech");
        Fabricante dell = new Fabricante("Dell");
        Fabricante samsung = new Fabricante("Samsung");
        
        //INSTANCIANDO PRODUTOS
        Produto HD = new Produto("SSD 870 EVO", "MZ-77E500", samsung);
        Produto mouse = new Produto("MOUSE", "G300s", logitech);
        Produto teclado = new Produto("TECLADO", "KB216", dell);
        
        //MOSTRANDO PRODUTOS E FABRICANTES
        System.out.println("---------HD---------------");
        System.out.println("");
        System.out.println("Nome: "+HD.getNome());
        System.out.println("Modelo: "+HD.getModelo());
        System.out.println("Fabricante: "+HD.getFabricante().getNome());
        System.out.println("");
        System.out.println("--------------------------");
        System.out.println("");
        
        System.out.println("---------MOUSE------------");
        System.out.println("");
        System.out.println("Nome: "+mouse.getNome());
        System.out.println("Modelo: "+mouse.getModelo());
        System.out.println("Fabricante: "+mouse.getFabricante().getNome());
        System.out.println("");
        System.out.println("--------------------------");
        System.out.println("");
        
        System.out.println("---------TECLADO----------");
        System.out.println("");
        System.out.println("Nome: "+teclado.getNome());
        System.out.println("Modelo: "+teclado.getModelo());
        System.out.println("Fabricante: "+teclado.getFabricante().getNome());
        System.out.println("");
        System.out.println("--------------------------");
        System.out.println("");
    }
    
}
