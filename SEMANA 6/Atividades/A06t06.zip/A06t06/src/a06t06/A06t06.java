package a06t06;

import static a06t06.Calendario.diaSemana;
import java.util.Scanner;

/*

    Aluno: Bruno Benicio de Andrade Lima
    Cidade: Castelo do Piauí - PI

 */
public class A06t06 {

    //  Crie uma classe chamada Calendario e incorpore nela os métodos criados nos exercícios 4 e 5;
    public static void main(String[] args) {
        Calendario cld = new Calendario();

        int i = 1;
        Scanner sc = new Scanner(System.in);

        System.out.println("Escolha de 1 a 7 para retornar um dia da semana: ");
        int option = sc.nextInt();

        if (option > 7 || option == 0) {
            System.out.println("Opção inválida, escolha de 1 a 7!");
        } else {
            System.out.println("Digite a opção de exibição do texto:");
            System.out.println("[" + i++ + "] Via prompt");
            System.out.println("[" + i++ + "] Via interface gráfica");
            int codigo = sc.nextInt();

            switch (codigo) {
                case 1:
                    cld.imprimir(option);
                    break;
                case 2:
                    cld.imprimir(diaSemana(option), 1);
                    break;
                default:
                    System.out.println("Opção Inválida!");
                    break;
            }
        }

    }
}
