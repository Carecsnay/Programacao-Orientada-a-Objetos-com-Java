package a06t06;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class Calendario {
    protected static String diaSemana(int numeroInserido) {
        List<String> dias = new ArrayList<>();
        dias.add("Domingo");
        dias.add("Segunda-Feira");
        dias.add("Terça-Feira");
        dias.add("Quarta-Feira");
        dias.add("Quinta-Feira");
        dias.add("Sexta-Feira");
        dias.add("Sábado");

        switch (numeroInserido) {
            case 1:
                return dias.get(0);
            case 2:
                return dias.get(1);
            case 3:
                return dias.get(2);
            case 4:
                return dias.get(3);
            case 5:
                return dias.get(4);
            case 6:
                return dias.get(5);
            case 7:
                return dias.get(6);
            default:
                System.out.println("Opção Inválida!");
                break;
        }
        return diaSemana(numeroInserido);
    }

    protected static String imprimir(int diaSemanaPrompt) {
        System.out.println("O dia escolhido foi: " + diaSemana(diaSemanaPrompt));
        return diaSemana(diaSemanaPrompt);
    }

    protected static String imprimir(String diaSemanaInterfaceGrafica, int tipoMensagem) {
        JOptionPane.showMessageDialog(null, diaSemanaInterfaceGrafica, "Interface Gráfica", tipoMensagem);
        return diaSemanaInterfaceGrafica;
    }
}
