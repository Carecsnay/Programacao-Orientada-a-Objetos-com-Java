package a06t01;

import java.util.Scanner;

/*

    Aluno: Bruno Benicio de Andrade Lima
    Cidade: Castelo do Piauí - PI

 */

public class A06t01 {
//  Crie um método que retorne o nome do indivíduo de acordo com o código inteiro passado por parâmetro;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int i = 1;
        
        System.out.println("Qual o nome você quer revelar?");
        System.out.println("["+i+++"º]Nome");
        System.out.println("["+i+++"º]Nome");
        System.out.println("["+i+++"º]Nome");
        System.out.println("["+i+++"º]Nome");
        
        int option = sc.nextInt();
        
        if (option > 4 || option == 0) {
            System.out.println("Opção inválida, rode o programa novamente!");
        }
        
        else {
            nome(option);
        }
        
    }
    
    private static int nome(int dado) {
        switch (dado) {
            case 1:
                System.out.println("O nome a ser revelado é: Bruno");
                break;
            case 2:
                System.out.println("O nome a ser revelado é: Marcia");
                break;
            case 3:
                System.out.println("O nome a ser revelado é: Jujuba");
                break;
            case 4:
                System.out.println("O nome a ser revelado é: Leon");
                break;
        }
        return dado;
    }
}