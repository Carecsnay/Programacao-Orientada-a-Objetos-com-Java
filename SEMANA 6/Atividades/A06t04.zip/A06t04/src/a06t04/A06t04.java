package a06t04;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/*

    Aluno: Bruno Benicio de Andrade Lima
    Cidade: Castelo do Piauí - PI

 */
public class A06t04 {

    /*    Crie um método que receba como parâmetro o dia da semana em formato inteiro 
      e retorne o nome do dia (segunda-feira, terça-feira etc);
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Escolha de 1 a 7 para retornar um dia da semana: ");
        int option = sc.nextInt();
        
        if (option > 7 || option == 0) {
            System.out.println("Opção inválida, rode o programa novamente!");
        }
        
        else {
            System.out.println("Convertendo...o dia escolhido foi: "+diaSemana(option));
        }
    }
    
    private static String diaSemana(int numeroInserido) {
        List<String> dias = new ArrayList<>();
        dias.add("Domingo");
        dias.add("Segunda-Feira");
        dias.add("Terça-Feira");
        dias.add("Quarta-Feira");
        dias.add("Quinta-Feira");
        dias.add("Sexta-Feira");
        dias.add("Sábado");
        
        switch (numeroInserido) {
            case 1:
                return dias.get(0);
            case 2:
                return dias.get(1);
            case 3:
                return dias.get(2);
            case 4:
                return dias.get(3);
            case 5:
                return dias.get(4);
            case 6:
                return dias.get(5);
            case 7:
                return dias.get(6);
        }
        return diaSemana(numeroInserido);
    }

}
