package a02ex01;

public class A02ex01 {
/*
    A02ex01
● Crie um programa que receba um argumento na linha de
comandos e retorne a mensagem conforme o exemplo:
– Se a linha de comandos for java -jar A02ex01.jar 1, o
resultado deve ser “O argumento passado foi: 1”
● Sugestão:
– Crie uma pasta na raiz da unidade “C:” ou utilize uma pasta já
criada no ambiente;
– Crie os projetos dentro dessa pasta;
– Entre na pasta e execute o comando com os argumentos.

*/
    public static void main(String[] args) {
        System.out.println("O argumento passado foi: "+args[0]);
    }
    
}
