package a02ex02;

public class A02ex02 {
/*
    A02ex02
● Crie um novo projeto, que mostre os três
argumentos da linha de comandos.

*/
    public static void main(String[] args) {
        System.out.println("O argumento passado foi: "+args[0]+" "+args[1]+" "+args[2]);
    }
    
}
