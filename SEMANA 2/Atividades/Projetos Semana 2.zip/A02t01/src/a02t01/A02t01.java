package a02t01;

/*

    Aluno: Bruno Benicio de Andrade Lima
    Cidade: Castelo do Piauí - PI

 */
public class A02t01 {
/*
    
    1 - 
    Crie um programa que possua uma variável com o seu nome, uma variável inteira e uma variável de número real e
    mostre os valores das variáveis (A02t01.jar);

*/   
    
    public static void main(String[] args) {
        String nomeUsuario = "BRUNO BENICIO DE ANDRADE LIMA";
        int idadeUsuario = 24;
        float alturaUsuario = (float) 1.72;
        
        System.out.println("Meu nome é: "+nomeUsuario);
        System.out.println("Eu tenho: "+idadeUsuario+" anos!");
        System.out.println("Minha altura é: "+alturaUsuario);
    }
            
}
