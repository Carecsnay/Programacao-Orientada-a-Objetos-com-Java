package a05ex03;

public class A05ex03 {

    public static void main(String[] args) {
        String[][] times = new String[5][2];
        times[0][0] = "João";
        times[0][1] = "Corinthias";
        times[1][0] = "José";
        times[1][1] = "São Paulo";
        times[2][0] = "Marcos";
        times[2][1] = "Palmeiras";
        times[3][0] = "Agnaldo";
        times[3][1] = "Cruzeiro";
        times[4][0] = "Joaquim";
        times[4][1] = "Inter";        
        
        for (String [] aux : times){
            System.out.println("Nome: "+aux[0]+" / Time: "+aux[1]);
        }
    }
}
