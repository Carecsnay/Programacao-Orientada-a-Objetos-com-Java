package forca;

import java.util.Scanner;

public class Forca {

    public static void main(String[] args) {
        int vidas = 7;
        String palpites = "";
        boolean gameOver;
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Digite a palavra secreta!");
        String palavra = sc.next();
        
        while (vidas > 0) {
            gameOver = true;
            for (int i = 0; i < palavra.length(); i++) {
                char x = palavra.charAt(i); //mostra as palavras verdadeiras e mostra _ nas palavras erradas
                if (palpites.matches(".*" + x + ".*")) { //verifica se as respostas estão contidas em X
                    System.out.print(x + " ");
                } else {
                    System.out.print("_ ");
                    gameOver = false;
                    /* se existir _ então não acabou o jogo*/
                }
            }
            
            if (gameOver) {
                System.out.println("\nParabéns você venceu!");
                break;
            }
            
            System.out.print("\nVidas Restantes = " + vidas + ", Digite uma letra: ");
            String letraDigitada = sc.next();

            if (!letraDigitada.matches("[a-z]|[A-Z]")) { //verifica se é uma letra! MAIUSC ou minusc.
                continue; //se não for uma letra o programa volta para o inicio do while.
            }
            
            if (palpites.matches(".*" + letraDigitada + ".*")) {
                System.out.println("\nOpa! Você já digitou essa letra, tente outra!");
                continue; //para não tirar as vidas
            }

            if (palavra.matches(".*" + letraDigitada + ".*")) {
                System.out.println("Acertou!");
            } else {
                System.out.println("Errou!");
                vidas--;
            }
            palpites += letraDigitada;
        }
        System.out.println("\nFim de jogo!");
    }
}